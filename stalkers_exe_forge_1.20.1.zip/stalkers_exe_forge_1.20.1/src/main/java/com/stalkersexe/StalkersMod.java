package com.stalkersexe;

import com.stalkersexe.client.ClientSetup;
import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModEntities;
import com.stalkersexe.registry.ModSounds;
import com.stalkersexe.server.StalkerCommand;
import com.stalkersexe.server.StalkerDirector;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.server.ServerLifecycleHooks;

@Mod(StalkersMod.MODID)
public class StalkersMod {
    public static final String MODID = "stalkers_exe";

    public StalkersMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        modBus.addListener(this::onAttributes);

        MinecraftForge.EVENT_BUS.addListener(this::onCommands);
        MinecraftForge.EVENT_BUS.addListener(this::onServerTick);

        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.init(modBus);
        }
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        for (StalkerKind k : StalkerKind.values()) {
            event.put(ModEntities.get(k), StalkerEntity.createAttributes().build());
        }
    }

    private void onCommands(RegisterCommandsEvent event) {
        StalkerCommand.register(event.getDispatcher());
    }

    private void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) StalkerDirector.tick(server);
    }
}
