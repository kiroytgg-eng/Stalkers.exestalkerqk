package com.stalkersexe.server;

import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

import java.util.*;

/** Logica global: eventos activos, contador de hunter_run, darkness, programacion automatica. */
public final class StalkerDirector {
    public static final int RUN_START = 500;
    public static final int RUN_FINAL = 0;              // umbral final: al llegar aqui aparece el stalker
    public static final boolean AUTO_HUNTER_RUN = true; // primera aparicion automatica entre los dias 7 y 9
    /** false = es_near.ogg suena al EMPEZAR el evento (contador); true = al empezar la persecucion. */
    public static final boolean ES_NEAR_AT_CHASE_START = false;
    public static final String TAG_DONE = "stalkers_exe_hunter_run_done";

    private enum Phase { COUNTDOWN, CHASE }

    private static final class RunEvent {
        final UUID player;
        double counter = RUN_START;
        long startTick;
        Phase phase = Phase.COUNTDOWN;
        UUID entity;
        RunEvent(UUID p, long start) { player = p; startTick = start; }
    }

    private static final Map<UUID, RunEvent> RUN = new HashMap<>();
    private static final Map<UUID, String> ACTIVE = new HashMap<>(); // jugador -> nombre del evento
    private static final Map<UUID, Long> PENDING_DARKNESS = new HashMap<>();

    private StalkerDirector() {}

    // ------------------------------------------------------------------ API de comandos
    public static String startEvent(ServerPlayer p, String name) {
        long gt = p.serverLevel().getGameTime();
        switch (name) {
            case "hunter_run" -> {
                RUN.put(p.getUUID(), new RunEvent(p.getUUID(), gt));
                ACTIVE.put(p.getUUID(), name);
                if (!ES_NEAR_AT_CHASE_START) StalkerAudio.playToPlayer(p, ModSounds.ES_NEAR, 1.0f);
                return "Evento hunter_run iniciado: contador en " + RUN_START + ".";
            }
            case "stalker_chase" -> {
                StalkerEntity e = StalkerSpawner.spawn(p, StalkerKind.STALKER4, true);
                if (e == null) return null;
                ACTIVE.put(p.getUUID(), name);
                return "Persecucion stalker_chase iniciada (stalker4 corriendo hacia ti).";
            }
            default -> {
                StalkerKind k = StalkerKind.byId(name);
                if (k == null) return null;
                StalkerEntity e = StalkerSpawner.spawn(p, k, false);
                if (e == null) return null;
                ACTIVE.put(p.getUUID(), name);
                return "Evento " + name + " iniciado.";
            }
        }
    }

    public static void stopAll(MinecraftServer server) {
        RUN.clear();
        ACTIVE.clear();
        despawnAll(server);
        for (ServerLevel sl : server.getAllLevels()) {
            StalkerAudio.stop(sl, ModSounds.KNOCK_SPOTTED);
            StalkerAudio.stop(sl, ModSounds.HUNT_MUSIC_BOX);
            StalkerAudio.stop(sl, ModSounds.HUNT_TENSION);
            StalkerAudio.stop(sl, ModSounds.MACHINE);
            StalkerAudio.stop(sl, ModSounds.ES_NEAR);
        }
    }

    public static int despawnAll(MinecraftServer server) {
        int n = 0;
        for (ServerLevel sl : server.getAllLevels()) {
            List<Entity> found = new ArrayList<>();
            for (Entity e : sl.getAllEntities()) if (e instanceof StalkerEntity) found.add(e);
            for (Entity e : found) { e.discard(); n++; }
        }
        return n;
    }

    public static List<String> status(MinecraftServer server) {
        List<String> out = new ArrayList<>();
        for (ServerLevel sl : server.getAllLevels()) {
            for (Entity e : sl.getAllEntities()) {
                if (e instanceof StalkerEntity s) {
                    out.add("- " + s.kind.id + " en " + sl.dimension().location() + " ("
                            + (int) s.getX() + ", " + (int) s.getY() + ", " + (int) s.getZ() + ") estado=" + s.getState());
                }
            }
        }
        for (RunEvent ev : RUN.values()) {
            ServerPlayer p = server.getPlayerList().getPlayer(ev.player);
            out.add("- hunter_run [" + (p == null ? ev.player : p.getName().getString()) + "] fase=" + ev.phase
                    + " contador=" + (int) Math.ceil(ev.counter));
        }
        if (out.isEmpty()) out.add("Sin eventos activos.");
        return out;
    }

    // ------------------------------------------------------------------ captura
    /** Llamado por la entidad cuando alcanza al jugador. */
    public static void onCaught(ServerPlayer p, StalkerKind kind) {
        boolean survivalLike = !p.isCreative() && !p.isSpectator();
        if (kind == StalkerKind.STALKER4) {
            applyDarkness(p);
            // la muerte borra los efectos: se re-aplica al reaparecer (3 s)
            if (survivalLike) PENDING_DARKNESS.put(p.getUUID(), p.serverLevel().getGameTime());
        }
        if (survivalLike) p.kill();
    }

    private static void applyDarkness(ServerPlayer p) {
        // 60 ticks = 3 s; ambient=false, particulas=false, icono=false
        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0, false, false, false));
    }

    // ------------------------------------------------------------------ tick
    public static void tick(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        long gt = overworld.getGameTime();

        // darkness pendiente tras reaparecer
        if (!PENDING_DARKNESS.isEmpty()) {
            Iterator<Map.Entry<UUID, Long>> it = PENDING_DARKNESS.entrySet().iterator();
            while (it.hasNext()) {
                var en = it.next();
                ServerPlayer p = server.getPlayerList().getPlayer(en.getKey());
                if (gt - en.getValue() > 20 * 60 * 20) { it.remove(); continue; }
                if (p != null && p.isAlive() && gt - en.getValue() > 5) { applyDarkness(p); it.remove(); }
            }
        }

        // primera aparicion automatica de hunter_run: dias 7-9, al caer la noche
        if (AUTO_HUNTER_RUN && gt % 100 == 0) {
            for (ServerPlayer p : overworld.players()) {
                if (p.getTags().contains(TAG_DONE) || RUN.containsKey(p.getUUID())) continue;
                if (!p.isAlive() || p.isCreative() || p.isSpectator()) continue;
                if (p.level().dimension() != Level.OVERWORLD) continue;
                long dayTime = overworld.getDayTime();
                long day = dayTime / 24000L;
                long tod = dayTime % 24000L;
                int scheduled = 7 + Math.floorMod(Long.hashCode(overworld.getSeed() ^ p.getUUID().getLeastSignificantBits()), 3);
                if (day >= scheduled && tod >= 13000 && tod < 22000) {
                    p.addTag(TAG_DONE);
                    startEvent(p, "hunter_run");
                }
            }
        }

        if (RUN.isEmpty()) return;
        Iterator<RunEvent> it = RUN.values().iterator();
        while (it.hasNext()) {
            RunEvent ev = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(ev.player);
            if (p == null || !p.isAlive()) { ACTIVE.remove(ev.player); it.remove(); continue; }
            ServerLevel sl = p.serverLevel();

            if (ev.phase == Phase.COUNTDOWN) {
                if (gt % 20 == 0) {
                    double elapsed = (gt - ev.startTick) / 20.0;
                    ev.counter -= danger(sl, p, elapsed);
                }
                if (ev.counter <= RUN_FINAL) {
                    ev.counter = RUN_FINAL;
                    StalkerEntity e = StalkerSpawner.spawn(p, StalkerKind.HUNTER_RUN, false);
                    if (e != null) {
                        ev.entity = e.getUUID();
                        ev.phase = Phase.CHASE;
                        if (ES_NEAR_AT_CHASE_START) StalkerAudio.playToPlayer(p, ModSounds.ES_NEAR, 1.0f);
                    } else {
                        ev.counter = 15; // no habia sitio: reintenta pronto
                    }
                }
                if (gt % 4 == 0) showCounter(p, ev);
            } else {
                Entity e = ev.entity == null ? null : sl.getEntity(ev.entity);
                if (e == null || e.isRemoved()) { ACTIVE.remove(ev.player); it.remove(); }
            }
        }
    }

    /**
     * Peligro (unidades por segundo). Crece con el tiempo (cada vez mas rapido),
     * y sube mas si el jugador esta a oscuras o es de noche. Total aprox. 2,5 min desde 500.
     */
    private static double danger(ServerLevel sl, ServerPlayer p, double elapsedSeconds) {
        double d = 1.0 + elapsedSeconds / 30.0;
        if (sl.getMaxLocalRawBrightness(p.blockPosition()) < 8) d += 1.0;
        long tod = sl.getDayTime() % 24000L;
        if (tod >= 13000 && tod < 23000) d += 0.5;
        return d;
    }

    /** Contador visible: barra de accion (no requiere red ni cliente propio). */
    private static void showCounter(ServerPlayer p, RunEvent ev) {
        int n = (int) Math.ceil(ev.counter);
        ChatFormatting color = n > 300 ? ChatFormatting.GRAY : n > 100 ? ChatFormatting.RED : ChatFormatting.DARK_RED;
        Component c = Component.literal(String.valueOf(n)).withStyle(color, ChatFormatting.BOLD);
        p.displayClientMessage(c, true);
    }
}
