package com.stalkersexe.server;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class StalkerCommand {
    private StalkerCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        var event = Commands.literal("event");
        for (String n : new String[]{"stalker_chase", "treepeek3", "hunter", "stalker4", "hunter_run"}) {
            event.then(Commands.literal(n).executes(c -> startEvent(c, n)));
        }
        event.then(Commands.literal("stop").executes(StalkerCommand::stop));
        event.then(Commands.literal("status").executes(StalkerCommand::status));

        var spawn = Commands.literal("spawn");
        for (StalkerKind k : StalkerKind.values()) {
            spawn.then(Commands.literal(k.id).executes(c -> spawn(c, k)));
        }

        d.register(Commands.literal("stalker")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("help").executes(StalkerCommand::help))
                .then(event)
                .then(spawn)
                .then(Commands.literal("despawn").then(Commands.literal("all").executes(StalkerCommand::despawnAll))));
    }

    private static int help(CommandContext<CommandSourceStack> c) {
        String[] lines = {
                "== Stalkers.exe ==",
                "/stalker help",
                "/stalker event <stalker_chase|treepeek3|hunter|stalker4|hunter_run>",
                "/stalker event stop | status",
                "/stalker spawn <treepeek3|hunter|stalker4|hunter_run>",
                "/stalker despawn all"
        };
        for (String l : lines) c.getSource().sendSuccess(() -> Component.literal(l), false);
        return 1;
    }

    private static int startEvent(CommandContext<CommandSourceStack> c, String name) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        String msg = StalkerDirector.startEvent(p, name);
        if (msg == null) {
            c.getSource().sendFailure(Component.literal("No se encontro un sitio valido cerca para " + name + ". Prueba en otra zona."));
            return 0;
        }
        c.getSource().sendSuccess(() -> Component.literal(msg), true);
        return 1;
    }

    private static int stop(CommandContext<CommandSourceStack> c) {
        StalkerDirector.stopAll(c.getSource().getServer());
        c.getSource().sendSuccess(() -> Component.literal("Eventos detenidos y stalkers eliminados."), true);
        return 1;
    }

    private static int status(CommandContext<CommandSourceStack> c) {
        for (String l : StalkerDirector.status(c.getSource().getServer())) {
            c.getSource().sendSuccess(() -> Component.literal(l), false);
        }
        return 1;
    }

    private static int spawn(CommandContext<CommandSourceStack> c, StalkerKind k) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        StalkerEntity e = StalkerSpawner.spawn(p, k, false);
        if (e == null) {
            c.getSource().sendFailure(Component.literal("No se encontro un sitio valido para " + k.id
                    + (k == StalkerKind.TREEPEEK3 ? " (necesita un arbol a 9-21 bloques)." : ".")));
            return 0;
        }
        c.getSource().sendSuccess(() -> Component.literal("Spawn: " + k.id), true);
        return 1;
    }

    private static int despawnAll(CommandContext<CommandSourceStack> c) {
        int n = StalkerDirector.despawnAll(c.getSource().getServer());
        c.getSource().sendSuccess(() -> Component.literal("Eliminados " + n + " stalkers."), true);
        return n;
    }
}
