package com.stalkersexe.server;

import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class StalkerSpawner {
    private StalkerSpawner() {}

    /** @return la entidad creada o null si no se encontro un sitio valido. */
    public static StalkerEntity spawn(ServerPlayer player, StalkerKind kind, boolean fastChase) {
        ServerLevel sl = player.serverLevel();
        Vec3 pos;
        switch (kind) {
            case TREEPEEK3 -> pos = findTree(sl, player);
            case HUNTER -> pos = findRing(sl, player, 30, 40, true);
            case STALKER4 -> pos = fastChase ? findRing(sl, player, 16, 20, false) : findRing(sl, player, 28, 36, false);
            default -> pos = findBehind(sl, player, 22, 26);
        }
        if (pos == null) return null;

        StalkerEntity e = ModEntities.get(kind).create(sl);
        if (e == null) return null;
        float yaw = (float) (Mth.atan2(player.getZ() - pos.z, player.getX() - pos.x) * (180.0 / Math.PI)) - 90.0f;
        e.moveTo(pos.x, pos.y, pos.z, yaw, 0.0f);
        e.yBodyRot = yaw;
        e.yHeadRot = yaw;
        e.setTarget(player);
        e.setFastChase(fastChase);
        sl.addFreshEntity(e);
        return e;
    }

    // ------------------------------------------------------------------ busqueda de posiciones
    private static Vec3 findRing(ServerLevel sl, ServerPlayer p, double min, double max, boolean frontCone) {
        RandomSource r = sl.getRandom();
        for (int i = 0; i < 40; i++) {
            double dist = min + r.nextDouble() * (max - min);
            double ang;
            if (frontCone) {
                double look = Math.toRadians(p.getYRot() + 90.0);
                ang = look + Math.toRadians((r.nextDouble() - 0.5) * 140.0);
            } else {
                ang = r.nextDouble() * Math.PI * 2;
            }
            Vec3 v = standable(sl, p.getX() + Math.cos(ang) * dist, p.getZ() + Math.sin(ang) * dist, p.getBlockY());
            if (v != null) return v;
        }
        return null;
    }

    private static Vec3 findBehind(ServerLevel sl, ServerPlayer p, double min, double max) {
        RandomSource r = sl.getRandom();
        for (int i = 0; i < 40; i++) {
            double dist = min + r.nextDouble() * (max - min);
            double ang = Math.toRadians(p.getYRot() + 90.0 + 180.0) + Math.toRadians((r.nextDouble() - 0.5) * 80.0);
            Vec3 v = standable(sl, p.getX() + Math.cos(ang) * dist, p.getZ() + Math.sin(ang) * dist, p.getBlockY());
            if (v != null) return v;
        }
        return null;
    }

    /** Busca un tronco y coloca al stalker pegado a el, ladeado, para que "se asome" por un costado. */
    private static Vec3 findTree(ServerLevel sl, ServerPlayer p) {
        RandomSource r = sl.getRandom();
        for (int i = 0; i < 80; i++) {
            double dist = 9 + r.nextDouble() * 12;
            double ang = r.nextDouble() * Math.PI * 2;
            int x = Mth.floor(p.getX() + Math.cos(ang) * dist);
            int z = Mth.floor(p.getZ() + Math.sin(ang) * dist);
            if (!sl.hasChunkAt(new BlockPos(x, 0, z))) continue;
            int top = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
            BlockPos log = new BlockPos(x, top, z);
            if (!sl.getBlockState(log).is(BlockTags.LOGS)) continue;
            while (sl.getBlockState(log.below()).is(BlockTags.LOGS)) log = log.below();

            double cx = log.getX() + 0.5, cz = log.getZ() + 0.5;
            double dx = p.getX() - cx, dz = p.getZ() - cz;
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 4) continue;
            dx /= len; dz /= len;
            double sign = r.nextBoolean() ? 1 : -1;
            double px = cx - dx * 0.55 + (-dz) * 0.62 * sign;
            double pz = cz - dz * 0.55 + (dx) * 0.62 * sign;
            double py = log.getY();
            if (sl.noCollision(new AABB(px - 0.35, py, pz - 0.35, px + 0.35, py + 2.9, pz + 0.35))) {
                return new Vec3(px, py, pz);
            }
        }
        return null;
    }

    /** Suelo firme con 2 bloques libres; heightmap en superficie, escaneo vertical en cuevas/Nether. */
    private static Vec3 standable(ServerLevel sl, double x, double z, int refY) {
        BlockPos col = BlockPos.containing(x, refY, z);
        if (!sl.hasChunkAt(col)) return null;
        if (!sl.dimensionType().hasCeiling()) {
            int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col.getX(), col.getZ());
            BlockPos feet = new BlockPos(col.getX(), y, col.getZ());
            if (!sl.getFluidState(feet.below()).isEmpty()) return null;
            return new Vec3(x, y, z);
        }
        for (int y = refY + 6; y >= refY - 8; y--) {
            BlockPos feet = new BlockPos(col.getX(), y, col.getZ());
            boolean free = sl.getBlockState(feet).getCollisionShape(sl, feet).isEmpty()
                    && sl.getBlockState(feet.above()).getCollisionShape(sl, feet.above()).isEmpty();
            boolean ground = !sl.getBlockState(feet.below()).getCollisionShape(sl, feet.below()).isEmpty();
            if (free && ground && sl.getFluidState(feet).isEmpty()) return new Vec3(x, y, z);
        }
        return null;
    }
}
