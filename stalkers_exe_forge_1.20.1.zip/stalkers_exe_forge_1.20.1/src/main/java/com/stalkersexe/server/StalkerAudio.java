package com.stalkersexe.server;

import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.registries.RegistryObject;

public final class StalkerAudio {
    private StalkerAudio() {}

    /** Sonido no posicional solo para ese jugador (sigue sonando aunque el stalker ya no exista). */
    public static void playToPlayer(ServerPlayer p, RegistryObject<SoundEvent> s, float volume) {
        p.playNotifySound(s.get(), SoundSource.HOSTILE, volume, 1.0f);
    }

    /** Detiene un sonido concreto para todos los jugadores del nivel. */
    public static void stop(ServerLevel level, RegistryObject<SoundEvent> s) {
        ClientboundStopSoundPacket pkt = new ClientboundStopSoundPacket(s.getId(), null);
        for (ServerPlayer p : level.players()) {
            p.connection.send(pkt);
        }
    }
}
