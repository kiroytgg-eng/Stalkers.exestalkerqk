package com.stalkersexe.registry;

import com.stalkersexe.StalkersMod;
import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, StalkersMod.MODID);

    private static final Map<StalkerKind, RegistryObject<EntityType<StalkerEntity>>> TYPES = new EnumMap<>(StalkerKind.class);

    static {
        for (StalkerKind kind : StalkerKind.values()) {
            TYPES.put(kind, ENTITIES.register(kind.id, () ->
                    EntityType.Builder.<StalkerEntity>of((type, level) -> new StalkerEntity(type, level, kind), MobCategory.MISC)
                            .sized(0.7f, kind.height)
                            .clientTrackingRange(10)
                            .updateInterval(2)
                            .fireImmune()
                            .build(StalkersMod.MODID + ":" + kind.id)));
        }
    }

    private ModEntities() {}

    public static EntityType<StalkerEntity> get(StalkerKind kind) {
        return TYPES.get(kind).get();
    }
}
