package com.stalkersexe.registry;

import com.stalkersexe.Compat;
import com.stalkersexe.StalkersMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StalkersMod.MODID);

    public static final RegistryObject<SoundEvent> KNOCK_SPOTTED = reg("knock_spotted");
    public static final RegistryObject<SoundEvent> HUNT_MUSIC_BOX = reg("hunt_music_box");
    public static final RegistryObject<SoundEvent> HUNT_TENSION = reg("hunt_tension");
    public static final RegistryObject<SoundEvent> MACHINE = reg("machinerunningsounds");
    public static final RegistryObject<SoundEvent> ES_NEAR = reg("es_near");

    private ModSounds() {}

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(Compat.id(name)));
    }
}
