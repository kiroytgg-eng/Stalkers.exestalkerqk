package com.stalkersexe;

import net.minecraft.resources.ResourceLocation;

public final class Compat {
    private Compat() {}

    public static ResourceLocation id(String path) {
        return new ResourceLocation(StalkersMod.MODID, path);
    }
}
