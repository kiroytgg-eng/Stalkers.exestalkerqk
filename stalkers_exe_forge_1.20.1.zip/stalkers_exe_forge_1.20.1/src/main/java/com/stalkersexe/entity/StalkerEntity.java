package com.stalkersexe.entity;

import com.stalkersexe.registry.ModSounds;
import com.stalkersexe.server.StalkerAudio;
import com.stalkersexe.server.StalkerDirector;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.RegistryObject;

import java.util.UUID;

/**
 * Entidad unica para los 4 stalkers; el comportamiento depende de {@link StalkerKind}.
 * No se guarda en disco: un stalker nunca sobrevive a un reinicio.
 */
public class StalkerEntity extends PathfinderMob {
    public static final int IDLE = 0, WALK = 1, RUN = 2, APPEAR = 3, DISAPPEAR = 4, ATTACK = 5;
    public static final int APPEAR_TICKS = 12, DISAPPEAR_TICKS = 10, ATTACK_TICKS = 8;

    private static final EntityDataAccessor<Integer> D_STATE =
            SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> D_PHASE_TICK =
            SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> D_WATCHED =
            SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.BOOLEAN);

    public final StalkerKind kind;

    private UUID targetId;
    private boolean fastChase;
    private boolean soundStarted;
    private int soundTimer;
    private int watchedTicks;
    private boolean caughtPlayer;

    public StalkerEntity(EntityType<? extends StalkerEntity> type, Level level, StalkerKind kind) {
        super(type, level);
        this.kind = kind;
        this.setInvulnerable(true);
        this.setSilent(true);
        this.setPersistenceRequired();
        this.setMaxUpStep(1.1f);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.12)
                .add(Attributes.FOLLOW_RANGE, 96.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(D_STATE, APPEAR);
        this.entityData.define(D_PHASE_TICK, 0);
        this.entityData.define(D_WATCHED, false);
    }

    // ------------------------------------------------------------------ estado sincronizado
    public int getState() { return this.entityData.get(D_STATE); }
    public int getPhaseTick() { return this.entityData.get(D_PHASE_TICK); }
    public boolean isWatched() { return this.entityData.get(D_WATCHED); }

    private void setState(int s) {
        if (getState() != s) {
            this.entityData.set(D_STATE, s);
            this.entityData.set(D_PHASE_TICK, this.tickCount);
        }
    }

    public void setTarget(ServerPlayer p) { this.targetId = p.getUUID(); }
    public void setFastChase(boolean v) { this.fastChase = v; }

    // ------------------------------------------------------------------ ajustes de entidad
    @Override public boolean isPushable() { return false; }
    @Override public boolean shouldBeSaved() { return false; }
    @Override public boolean removeWhenFarAway(double dist) { return false; }

    // ------------------------------------------------------------------ logica de servidor
    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            serverTick();
        }
    }

    private void serverTick() {
        ServerLevel sl = (ServerLevel) this.level();
        Player p = targetId == null ? null : sl.getPlayerByUUID(targetId);
        int state = getState();
        int age = this.tickCount - getPhaseTick();

        if (state == DISAPPEAR) {
            if (age >= DISAPPEAR_TICKS) this.discard();
            return;
        }
        if (p == null || !p.isAlive() || p.level() != this.level()) {
            vanish(sl);
            return;
        }

        lookAtPlayer(p);

        boolean watched = isLookedAt(p);
        this.entityData.set(D_WATCHED, watched);
        watchedTicks = watched ? watchedTicks + 1 : 0;

        if (state == APPEAR) {
            if (age >= APPEAR_TICKS) setState(kind.isChaser() ? WALK : IDLE);
            return;
        }
        if (state == ATTACK) {
            this.getNavigation().stop();
            if (age >= ATTACK_TICKS && !caughtPlayer && p instanceof ServerPlayer sp) {
                caughtPlayer = true;
                StalkerDirector.onCaught(sp, kind);
                beginDisappear();
            }
            return;
        }

        switch (kind) {
            case TREEPEEK3 -> tickTreePeek();
            case HUNTER -> tickHunter(sl, (ServerPlayer) p);
            case STALKER4 -> tickChaser(p, 130 * 20);
            case HUNTER_RUN -> tickChaser(p, 100 * 20);
        }
    }

    /** Se asoma, observa, reproduce knock_spotted.ogg y desaparece cuando termina el sonido. */
    private void tickTreePeek() {
        setState(IDLE);
        if (!soundStarted) {
            soundStarted = true;
            soundTimer = 0;
            play(ModSounds.KNOCK_SPOTTED, 3.0f);
        }
        if (++soundTimer >= kind.soundTicks) {
            beginDisappear();
        }
    }

    /** Aparece lejos con hunt_music_box.ogg; si lo miran: hunt_tension.ogg y desaparece. */
    private void tickHunter(ServerLevel sl, ServerPlayer p) {
        setState(IDLE);
        if (!soundStarted || soundTimer >= kind.soundTicks) {
            soundStarted = true;
            soundTimer = 0;
            play(ModSounds.HUNT_MUSIC_BOX, 4.0f);
        }
        soundTimer++;

        if (watchedTicks >= 4) {
            StalkerAudio.stop(sl, ModSounds.HUNT_MUSIC_BOX);
            StalkerAudio.playToPlayer(p, ModSounds.HUNT_TENSION, 1.0f);
            beginDisappear();
        } else if (this.tickCount > 75 * 20) {
            StalkerAudio.stop(sl, ModSounds.HUNT_MUSIC_BOX);
            beginDisappear();
        }
    }

    /** stalker4 / hunter_run: persiguen al jugador y lo eliminan al alcanzarlo. */
    private void tickChaser(Player p, int maxTicks) {
        double dist = this.distanceTo(p);

        if (kind == StalkerKind.STALKER4) {
            if (!soundStarted || soundTimer >= kind.soundTicks) {
                soundStarted = true;
                soundTimer = 0;
                play(ModSounds.MACHINE, 4.0f);
            }
            soundTimer++;
        }

        double speed;
        if (kind == StalkerKind.HUNTER_RUN) speed = 1.6;
        else if (fastChase) speed = 1.7;
        else speed = dist < 10 ? 1.25 : 0.95;

        if (dist < 1.9) {
            this.getNavigation().stop();
            setState(ATTACK);
            return;
        }

        if (this.tickCount % 4 == 0 || this.getNavigation().isDone()) {
            this.getNavigation().moveTo(p, speed);
        }
        if (this.getNavigation().isDone() && dist > 3) {
            Vec3 d = p.position().subtract(this.position());
            Vec3 n = new Vec3(d.x, 0, d.z).normalize().scale(0.04 * speed);
            this.setDeltaMovement(this.getDeltaMovement().add(n));
        }
        if (this.horizontalCollision && this.onGround()) {
            this.getJumpControl().jump();
        }

        setState(speed > 1.1 ? RUN : WALK);

        if (this.tickCount > maxTicks) {
            beginDisappear();
        }
    }

    // ------------------------------------------------------------------ look at
    private void lookAtPlayer(Player p) {
        this.getLookControl().setLookAt(p, 40.0f, 40.0f);
        if (!kind.isChaser() || getState() == ATTACK) {
            double dx = p.getX() - this.getX();
            double dz = p.getZ() - this.getZ();
            float want = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
            float yaw = Mth.approachDegrees(this.getYRot(), want, 5.0f);
            this.setYRot(yaw);
            this.yBodyRot = yaw;
        }
    }

    /** El jugador lo mira directamente (cono de ~12 grados) y hay linea de vision. */
    private boolean isLookedAt(Player p) {
        Vec3 view = p.getViewVector(1.0f).normalize();
        Vec3 toHead = new Vec3(this.getX() - p.getX(),
                this.getY() + kind.height * 0.85 - p.getEyeY(),
                this.getZ() - p.getZ()).normalize();
        return view.dot(toHead) > 0.978 && p.hasLineOfSight(this);
    }

    // ------------------------------------------------------------------ utilidades
    private void play(RegistryObject<SoundEvent> s, float volume) {
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), s.get(), SoundSource.HOSTILE, volume, 1.0f);
    }

    private void vanish(ServerLevel sl) {
        if (kind == StalkerKind.HUNTER) StalkerAudio.stop(sl, ModSounds.HUNT_MUSIC_BOX);
        beginDisappear();
    }

    public void beginDisappear() {
        this.getNavigation().stop();
        setState(DISAPPEAR);
    }
}
