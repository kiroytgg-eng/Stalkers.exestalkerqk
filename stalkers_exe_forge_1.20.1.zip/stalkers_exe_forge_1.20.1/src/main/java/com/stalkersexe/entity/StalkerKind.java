package com.stalkersexe.entity;

public enum StalkerKind {
    // id, altura en bloques, duracion del sonido principal en ticks (medida con ffprobe sobre los OGG originales)
    TREEPEEK3("treepeek3", 2.9f, 288),   // knock_spotted.ogg      14.399 s
    HUNTER("hunter", 2.3f, 222),         // hunt_music_box.ogg     11.076 s
    STALKER4("stalker4", 3.0f, 229),     // machinerunningsounds   11.424 s
    HUNTER_RUN("hunter_run", 3.2f, 0);   // es_near.ogg lo reproduce el director

    public final String id;
    public final float height;
    public final int soundTicks;

    StalkerKind(String id, float height, int soundTicks) {
        this.id = id;
        this.height = height;
        this.soundTicks = soundTicks;
    }

    public boolean isChaser() {
        return this == STALKER4 || this == HUNTER_RUN;
    }

    public static StalkerKind byId(String id) {
        for (StalkerKind k : values()) if (k.id.equals(id)) return k;
        return null;
    }
}
