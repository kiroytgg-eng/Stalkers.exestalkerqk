package com.stalkersexe.client;

import com.stalkersexe.Compat;
import com.stalkersexe.entity.StalkerKind;
import net.minecraft.resources.ResourceLocation;

import java.util.EnumMap;
import java.util.Map;

/**
 * Regiones (en pixeles) de cada PNG ORIGINAL usadas como piezas del modelo.
 * Los PNG no se modifican: solo se recortan por UV en tiempo de render.
 * Valores medidos con un analisis de la silueta (canal alfa) de cada textura.
 */
public final class Sprites {
    public static final class Spec {
        public final ResourceLocation texture;
        public final int size;                 // textura cuadrada size x size
        public final int x0, y0, x1, y1;       // bbox de la silueta
        public final int headCx, neckY;        // pivote de la cabeza
        public final int crotchY, splitX;      // inicio de piernas y division izq/der (-1 = sin piernas)
        public final float height;             // altura en bloques

        Spec(String tex, int size, int x0, int y0, int x1, int y1, int headCx, int neckY, int crotchY, int splitX, float height) {
            this.texture = Compat.id("textures/entity/" + tex + ".png");
            this.size = size; this.x0 = x0; this.y0 = y0; this.x1 = x1; this.y1 = y1;
            this.headCx = headCx; this.neckY = neckY; this.crotchY = crotchY; this.splitX = splitX; this.height = height;
        }
    }

    private static final Map<StalkerKind, Spec> SPECS = new EnumMap<>(StalkerKind.class);
    static {
        SPECS.put(StalkerKind.TREEPEEK3,  new Spec("treepeek3", 480, 138, 16, 346, 480, 212, 104, -1, -1, 2.9f));
        SPECS.put(StalkerKind.HUNTER,     new Spec("hunter", 1024, 32, 23, 1007, 893, 496, 305, 590, 423, 2.3f));
        SPECS.put(StalkerKind.STALKER4,   new Spec("stalker4", 1024, 330, 47, 693, 1024, 509, 205, 515, 512, 3.0f));
        SPECS.put(StalkerKind.HUNTER_RUN, new Spec("hunter_run", 1024, 162, 7, 818, 1024, 640, 295, 690, 480, 3.2f));
    }

    private Sprites() {}

    public static Spec get(StalkerKind k) { return SPECS.get(k); }
}
