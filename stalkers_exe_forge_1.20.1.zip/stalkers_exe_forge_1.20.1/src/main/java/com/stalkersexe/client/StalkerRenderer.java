package com.stalkersexe.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.stalkersexe.entity.StalkerEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Renderer 1.20.1. Modelo "marioneta": cabeza, torso y mitades inferiores recortadas del PNG
 * original (UV) y animadas por codigo. El sprite siempre se orienta hacia el jugador local;
 * la cabeza gira aparte (look at) y tiembla cuando el jugador la mira.
 */
public class StalkerRenderer extends EntityRenderer<StalkerEntity> {

    public StalkerRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0f;
    }

    @Override
    public ResourceLocation getTextureLocation(StalkerEntity e) {
        return Sprites.get(e.kind).texture;
    }

    /** Parametros de animacion calculados por fotograma. */
    private static final class Anim {
        float alpha = 1f, jitterX, bob, lungeZ;
        float bodyRoll, bodyPitch, scaleY = 1f;
        float headRoll, headYaw, headPitch;
        float legSwing, legSide;
        int light;
    }

    @Override
    public void render(StalkerEntity e, float entityYaw, float pt, PoseStack pose, MultiBufferSource buffers, int light) {
        Sprites.Spec sp = Sprites.get(e.kind);
        Anim a = animate(e, pt);
        a.light = light;

        if (a.alpha > 0.01f) {
            LocalPlayer lp = Minecraft.getInstance().player;
            float faceYaw = lp == null ? 0f
                    : (float) Math.toDegrees(Math.atan2(lp.getX() - e.getX(), lp.getZ() - e.getZ()));

            pose.pushPose();
            pose.mulPose(Axis.YP.rotationDegrees(faceYaw));
            VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(sp.texture));
            draw(pose.last().pose(), pose.last().normal(), vc, sp, a);
            pose.popPose();
        }
        super.render(e, entityYaw, pt, pose, buffers, light);
    }

    // ------------------------------------------------------------------ animaciones
    private static Anim animate(StalkerEntity e, float pt) {
        Anim a = new Anim();
        float t = e.tickCount + pt;
        int st = e.getState();
        float phaseAge = (e.tickCount - e.getPhaseTick()) + pt;

        float headRel = Mth.wrapDegrees(Mth.rotLerp(pt, e.yHeadRotO, e.yHeadRot) - Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot));
        float pitch = e.getViewXRot(pt);
        float walkPos = e.walkAnimation.position(pt);
        float walkSpeed = e.walkAnimation.speed(pt);

        // idle (siempre presente): respiracion, balanceo y cabeza ladeada
        a.bodyRoll = Mth.sin(t * 0.07f) * 1.5f;
        a.scaleY = 1f + Mth.sin(t * 0.11f) * 0.012f;
        a.headRoll = Mth.sin(t * 0.045f) * 4f + Mth.clamp(headRel * 0.25f, -15f, 15f);
        a.headYaw = Mth.clamp(headRel, -50f, 50f);
        a.headPitch = Mth.clamp(pitch, -25f, 25f) * 0.5f;

        // reaccion cuando el jugador lo mira
        if (e.isWatched()) {
            a.headRoll += Mth.sin(t * 2.3f) * 3.5f;
            a.jitterX += Mth.sin(t * 3.7f) * 0.012f;
        }

        // caminar / correr
        boolean running = st == StalkerEntity.RUN;
        if (st == StalkerEntity.WALK || running || walkSpeed > 0.05f) {
            float k = running ? 1.6f : 1f;
            float ph = walkPos * 0.9f * k;
            a.legSwing = Mth.cos(ph) * (running ? 38f : 22f);
            a.legSide = Mth.sin(ph) * (running ? 6f : 3f);
            a.bob = Math.abs(Mth.sin(ph)) * 0.05f * k;
            a.bodyPitch = running ? 14f : 5f;
            a.bodyRoll += Mth.sin(ph) * 3f * k;
        }

        // aparecer: parpadeo/glitch + fundido
        if (st == StalkerEntity.APPEAR) {
            float p = Mth.clamp(phaseAge / StalkerEntity.APPEAR_TICKS, 0f, 1f);
            a.alpha = p * p * (Mth.sin(phaseAge * 5f) > -0.6f ? 1f : 0.3f);
            a.jitterX += (1f - p) * 0.15f * Mth.sin(phaseAge * 9f);
            a.scaleY *= 0.85f + 0.15f * p;
        }
        // desaparecer: fundido + sacudida + cabeza que cae
        if (st == StalkerEntity.DISAPPEAR) {
            float p = Mth.clamp(phaseAge / StalkerEntity.DISAPPEAR_TICKS, 0f, 1f);
            a.alpha = 1f - p;
            a.jitterX += p * 0.2f * Mth.sin(phaseAge * 11f);
            a.scaleY *= 1f - 0.1f * p;
            a.headRoll += p * 25f;
        }
        // atacar: abalanzarse hacia el jugador
        if (st == StalkerEntity.ATTACK) {
            float p = Mth.clamp(phaseAge / StalkerEntity.ATTACK_TICKS, 0f, 1f);
            a.bodyPitch = 35f * Mth.sin(p * (float) Math.PI * 0.5f);
            a.lungeZ = 0.5f * Mth.sin(p * (float) Math.PI * 0.5f);
            a.scaleY *= 1f + 0.2f * p;
            a.headYaw = 0f;
            a.headRoll += Mth.sin(phaseAge * 3f) * 6f;
        }
        return a;
    }

    // ------------------------------------------------------------------ geometria
    private static float rad(float deg) { return deg * ((float) Math.PI / 180f); }

    private static void draw(Matrix4f pose, Matrix3f normal, VertexConsumer vc, Sprites.Spec sp, Anim a) {
        float k = sp.height / (sp.y1 - sp.y0);          // bloques por pixel
        float cx = (sp.x0 + sp.x1) / 2f;
        int alpha = Math.round(Mth.clamp(a.alpha, 0f, 1f) * 255f);

        Matrix4f root = new Matrix4f(pose).translate(a.jitterX, a.bob, a.lungeZ);

        boolean legs = sp.crotchY > 0;
        float hipY = legs ? sp.crotchY : sp.neckY + (sp.y1 - sp.neckY) * 0.6f;
        float hipWorldY = (sp.y1 - hipY) * k;

        // torso: pivota en la cadera
        Matrix4f body = new Matrix4f(root)
                .translate(0, hipWorldY, 0)
                .rotateX(rad(a.bodyPitch)).rotateZ(rad(a.bodyRoll))
                .scale(1f, a.scaleY, 1f)
                .translate(0, -hipWorldY, 0);
        float bodyBottom = legs ? sp.crotchY : sp.y1;
        part(body, normal, vc, sp, k, cx, sp.x0, sp.neckY, sp.x1, bodyBottom, alpha, a.light, 0f);

        // cabeza: pivota en el cuello; gira (yaw), cabecea (pitch) y se ladea (roll)
        float hx = (sp.headCx - cx) * k, hy = (sp.y1 - sp.neckY) * k;
        Matrix4f head = new Matrix4f(body)
                .translate(hx, hy, 0.004f)
                .rotateY(rad(a.headYaw)).rotateX(rad(a.headPitch)).rotateZ(rad(a.headRoll))
                .translate(-hx, -hy, 0);
        part(head, normal, vc, sp, k, cx, sp.x0, sp.y0, sp.x1, sp.neckY + 5, alpha, a.light, 0f);

        // mitades inferiores (izquierda/derecha), con balanceo alterno
        if (legs) {
            float px = (sp.splitX - cx) * k;
            for (int side = 0; side < 2; side++) {
                float sgn = side == 0 ? 1f : -1f;
                Matrix4f m = new Matrix4f(root)
                        .translate(px, hipWorldY, 0)
                        .rotateX(rad(a.legSwing * sgn)).rotateZ(rad(a.legSide * sgn))
                        .translate(-px, -hipWorldY, 0);
                float xa = side == 0 ? sp.x0 : sp.splitX;
                float xb = side == 0 ? sp.splitX : sp.x1;
                part(m, normal, vc, sp, k, cx, xa, sp.crotchY, xb, sp.y1, alpha, a.light, 0.002f * side);
            }
        }
    }

    /** Dibuja un rectangulo de la textura (coords en pixeles) como quad de dos caras. */
    private static void part(Matrix4f m, Matrix3f n, VertexConsumer vc, Sprites.Spec sp, float k, float cx,
                             float px0, float py0, float px1, float py1, int alpha, int light, float z) {
        float xl = (px0 - cx) * k, xr = (px1 - cx) * k;
        float yt = (sp.y1 - py0) * k, yb = (sp.y1 - py1) * k;
        float ul = px0 / sp.size, ur = px1 / sp.size, vt = py0 / sp.size, vb = py1 / sp.size;
        // cara frontal (antihoraria vista desde +Z)
        v(m, n, vc, xl, yt, z, ul, vt, alpha, light, 1f);
        v(m, n, vc, xl, yb, z, ul, vb, alpha, light, 1f);
        v(m, n, vc, xr, yb, z, ur, vb, alpha, light, 1f);
        v(m, n, vc, xr, yt, z, ur, vt, alpha, light, 1f);
        // cara trasera
        float zb = z - 0.001f;
        v(m, n, vc, xl, yt, zb, ul, vt, alpha, light, -1f);
        v(m, n, vc, xr, yt, zb, ur, vt, alpha, light, -1f);
        v(m, n, vc, xr, yb, zb, ur, vb, alpha, light, -1f);
        v(m, n, vc, xl, yb, zb, ul, vb, alpha, light, -1f);
    }

    private static void v(Matrix4f m, Matrix3f n, VertexConsumer vc, float x, float y, float z,
                          float u, float vv, int alpha, int light, float nz) {
        vc.vertex(m, x, y, z)
          .color(255, 255, 255, alpha)
          .uv(u, vv)
          .overlayCoords(OverlayTexture.NO_OVERLAY)
          .uv2(light)
          .normal(n, 0f, 0f, nz)
          .endVertex();
    }
}
