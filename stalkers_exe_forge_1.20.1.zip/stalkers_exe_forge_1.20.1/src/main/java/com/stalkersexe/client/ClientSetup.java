package com.stalkersexe.client;

import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModEntities;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.IEventBus;

/** Solo se invoca en el cliente (ver StalkersMod). */
public final class ClientSetup {
    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerRenderers);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (StalkerKind k : StalkerKind.values()) {
            event.registerEntityRenderer(ModEntities.get(k), StalkerRenderer::new);
        }
    }
}
