# Stalkers.exe — mod de terror para Minecraft Java 1.20.1 (Forge 47.4.0)

## Estado real (leer primero)
| Cosa | Estado |
|---|---|
| Inspeccion del zip (texturas/sonidos/modelos) | Hecho |
| Forge para 1.20.1 | Existe: 47.4.0 es la build recomendada (hay builds posteriores, p. ej. 47.4.10) |
| Codigo Java: sintaxis | Comprobada con javac (-source 17): 0 errores de parseo |
| **Compilacion contra Minecraft/Forge** | **NO realizada** (mi entorno no tiene red, Gradle ni jars de MC) |
| **Archivo .jar** | **NO generado** |
| **Ejecucion en el juego** | **NO probada** |

El codigo esta escrito para la API de 1.20.1 (Mojang mappings, Forge 47), pero no lo he compilado. Tendras que compilar tu (abajo).

## Inspeccion de Stalkers.zip
- **Modelos/animaciones: ninguno.** Solo 26 PNG y 39 OGG.
- Los PNG son siluetas 2D de cuerpo completo con fondo transparente (480x480 o 1024x1024), no skins UV.
- Usados: `treepeek3`, `hunter`, `stalker4`, `hunter_run` y los sonidos `knock_spotted`, `hunt_music_box`, `hunt_tension`, `machinerunningsounds`, `es_near`.
- Todos los PNG/OGG originales estan **sin modificar** en `src/main/resources/assets/stalkers_exe/` (texturas no usadas en `textures/entity/originales/`). Los OGG son estereo: no hay panoramizacion direccional.
- Modelo creado: "marioneta" de 4 piezas (cabeza, torso, mitad izquierda, mitad derecha) recortadas por UV del PNG original (`client/Sprites.java`), animada por codigo: idle, caminar, correr, aparecer, desaparecer, atacar + look-at.

## Instalacion / compilacion
Requisitos: **JDK 17**, Minecraft Java 1.20.1, Forge 1.20.1-47.4.0 (o posterior 47.x).

**Ruta recomendada (MDK oficial)**
1. Descarga el MDK de Forge 1.20.1-47.4.0 en https://files.minecraftforge.net y descomprimelo.
2. Reemplaza su `src/main` por el de este proyecto (`java` y `resources`).
3. En su `gradle.properties` pon `mod_id=stalkers_exe` (y el `mod_version` que quieras).
4. `./gradlew build` → el jar queda en `build/libs/stalkers_exe-1.0.0.jar`. Copialo a `.minecraft/mods/` con Forge instalado.

**Ruta alternativa:** `build.gradle`/`settings.gradle` incluidos (estructura estandar de ForgeGradle 6, sin verificar y sin wrapper). Con Gradle 8.1.1: `gradle wrapper --gradle-version 8.1.1 && ./gradlew build`.

## Comandos (requieren OP nivel 2)
```
/stalker help
/stalker event stalker_chase | treepeek3 | hunter | stalker4 | hunter_run
/stalker event stop | status
/stalker spawn treepeek3 | hunter | stalker4 | hunter_run
/stalker despawn all
```

## Comportamiento
- **treepeek3**: busca un tronco a 9–21 bloques y aparece pegado, ladeado; reproduce `knock_spotted.ogg` y desaparece al terminar (288 ticks = duracion medida del OGG).
- **hunter**: aparece a 30–40 bloques; `hunt_music_box.ogg` en bucle; al mirarlo (cono ~12°, con linea de vision) corta la caja de musica, reproduce `hunt_tension.ogg` solo para ti y desaparece. Si nadie lo mira, se va a los 75 s.
- **stalker4**: aparece a 28–36 bloques con `machinerunningsounds.ogg` en bucle, camina/corre hacia ti; al alcanzarte te mata y aplica Darkness 3 s sin particulas ni icono.
- **hunter_run**: contador 500 → 0 en la barra de accion; la bajada se acelera con el tiempo (+1/s cada 30 s), mas si estas a oscuras (+1) o es de noche (+0,5); dura ~2,5 min. Al llegar a 0 aparece detras de ti y te persigue (mas rapido que tu al correr). `es_near.ogg` suena al empezar el evento. Primera aparicion automatica: dia 7, 8 o 9 (segun semilla+jugador), al caer la noche, una vez por jugador (etiqueta `stalkers_exe_hunter_run_done`).
- **Look at**: la cabeza sigue al jugador (LookControl), el cuerpo gira lento, el sprite se orienta hacia tu camara, la cabeza se ladea y tiembla cuando la miras.

## Interpretaciones que tome
1. `stalker_chase` no estaba definido: es un stalker4 que aparece a 16–20 bloques y corre.
2. `es_near.ogg` suena al **iniciar el contador**. Para la persecucion, `ES_NEAR_AT_CHASE_START = true` en `StalkerDirector`.
3. Darkness: la muerte borra efectos, asi que se aplica al alcanzarte y se **re-aplica 3 s al reaparecer**. En creativo/espectador no mata.
4. El contador es **barra de accion**, no un HUD propio.
5. Los stalkers no se guardan en el mundo.
6. Alcance de sonido por volumen en `level.playSound` (3–4 = 48–64 bloques).

## Puntos a vigilar si el compilador se queja (API 1.20.1 escrita de memoria)
- `StalkerEntity`: `setMaxUpStep(float)`, `onGround()`, `defineSynchedData()` sin builder.
- `client/StalkerRenderer`: `walkAnimation.position/speed`, `getViewXRot`, `com.mojang.math.Axis`, `normal(Matrix3f,...)`.
- `server/*`: `ClientboundStopSoundPacket(ResourceLocation, SoundSource)`, `player.serverLevel()`, `sendSuccess(Supplier,...)`.
- `StalkersMod`: evento `TickEvent.ServerTickEvent`.
- `pack.mcmeta`: `pack_format` 15 (1.20.1).

Si pegas aqui los errores de compilacion, los corrijo.

## Pruebas sugeridas (no realizadas por mi)
`/stalker spawn treepeek3` · `/stalker spawn hunter` y mirarlo · `/stalker spawn stalker4` y dejar que te alcance · `/stalker event hunter_run` y vigilar la barra de accion · `/stalker event status` · `/stalker despawn all`.
